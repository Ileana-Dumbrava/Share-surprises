package bags;

public interface IBagFactory {

	IBag makeBag(String type);
}
