package surprise;

public interface ISurprise {

	void enjoy();
}
